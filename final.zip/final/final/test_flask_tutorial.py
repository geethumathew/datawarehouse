# -*- coding: utf-8 -*-

#Importing required packages
from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import requests
import csv
import string
from elasticsearch import Elasticsearch, helpers
from nltk import word_tokenize
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer, TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics.pairwise import cosine_similarity

#Defining app
app = Flask(__name__ )

#Index
@app.route('/')
def demo():
    return render_template('index.html')

#Services
@app.route('/services')
def services():
    return render_template('sample.html')

#serv_home
@app.route('/serv')
def serv():
    return render_template('serv.html')

#About us
@app.route('/aboutus')
def about():
    return render_template('index.html')

#Contact us
@app.route('/contactus')
def contact():
    return render_template('contactus.html')

#Networking
@app.route('/network')
def network():
    return render_template('network.html')    

#people
@app.route('/people')
def people():
    return render_template('people.html')

#classification
@app.route('/classification')
def classification():
    return render_template('classification.html')


@app.route("/classifier",methods=['POST'])
def classify():
    if request.method =='POST':
       idea = request.form['idea']
       # LOAD DATA FROM CSV
       Sample_data = pd.read_excel('ideadata.xlsx',encoding='UTF-8')
       traindata = Sample_data.iloc[1:400, 0:2]
       testdata = Sample_data.iloc[401:661, 0:2]
       # SEPARATE TEXT VECTOR TO CREATE Source(),
       # Corpus() CONSTRUCTOR FOR DOCUMENT TERM
       # MATRIX TAKES Source()
       trainvector = traindata['Idea']
       testvector = testdata['Idea']
       # Tokenizer
       def tokenize(text):
           text = "".join([ch for ch in text if ch not in string.punctuation])
           tokens = word_tokenize(text)
           return tokens
       # CREATE SOURCE FOR VECTOR
       # CREATE CORPUS FOR DATA
       # PERFORMING THE VARIOUS TRANSFORMATION on "traincorpus" and "testcorpus" 
       # SUCH AS TRIM WHITESPACE, REMOVE PUNCTUATION, REMOVE STOPWORDS.
       #trainmatrix=vec.fit_transform(trainvector)
       #tfidf_transformer = TfidfTransformer()
       #trainmatrix_tfidf = tfidf_transformer.fit_transform(trainmatrix)
       #p=np.asarray(trainmatrix_tfidf)
       text_clf_svm = Pipeline([('vect', CountVectorizer(analyzer='word', lowercase=True, stop_words='english',tokenizer=tokenize)),('tfidf', TfidfTransformer()),('clf-svm', SGDClassifier(loss='hinge', penalty='l2',alpha=1e-3, n_iter=5, random_state=42))])
       label=np.asarray(traindata['labels'])
       _ = text_clf_svm.fit(trainvector.values.astype('U'), label)
       predicted_svm = text_clf_svm.predict(testvector.values.astype('U'))
       predicted_svm
       actual=np.asarray(testdata['labels'])
       np.mean(predicted_svm == actual)
       #test=['We seek to apply natural language, information extraction and machine learning methods to build semantic representations of individual texts and large corpora such as the WWW.']
       test=[idea]
       #test=['The GPS systems are todays most well known location tracking systems. Well these systems are not capable of pinpointing exact locations or locations of an entity within a building or on a particular floor or room. So here we propose a smart asset tracking system that allows to track location of objects, goods, personnel within a building or any facility.']
       #testm = vec.transform(test)
       result=text_clf_svm.predict(test)
       #print(result)
       #result_text=np.array_str(result)
       return render_template("classresult.html",result=result[0])
       #print(result[0])
       #return result

#IDEA_SIMILARITY
@app.route('/similar_ideas')
def similarideas():
    return render_template('similar_ideas.html')

@app.route("/similarideas",methods=['POST'])
def similarity():
    if request.method =='POST':
        sm = request.form['sm']
    data=pd.read_excel('data.xlsx')
    idea=data.iloc[:,0:1]
    #idea=idea.set_index('Idea')
    corpus=[]
    for index,row in idea.iterrows():
        corpus.append(row['Idea'])
    #length of corpus
    len_corpus=len(corpus)
    #tfidf vectoriser
    test=[sm]
    #test=['LiveChat comes with a built-in online ticketing system. It allows you to handle all your support activities from one place. If a chat can’t be resolved in one touch, agents can escalate it to a ticket to deal with it later.']
    #test=['GIS Based Vehicle Tracking System is one good project. Using GPS receivers, you can develop an efficient system that gives walking directions, bus travel routes, sightseeing, navigation for the blind etc.']
    #test=['online ticketing system']
    #test=['Landmark Solutions/ Location Identification']
    #test=["I want an automatic permission system, that connects with colleges's database and sends mail to coreesponding staff to get permission."]
    #corpus.append(test)
    vectorizer = TfidfVectorizer()
    X=vectorizer.fit_transform(test)
    Xt=vectorizer.transform(np.array(corpus).astype(str))
    #Cosine Similarity
    score=cosine_similarity(Xt,X)
    #Linking scores with the ideas
    idea_index_with_score={}
    for i in range(len_corpus):
        idea_index_with_score.update({i:score[i]})
    #Sorting ideas based on score
    sorted_index = sorted(idea_index_with_score, key=lambda x : idea_index_with_score[x], reverse=True)
    #finding top 5 similar ideas
    top5_index=sorted_index[:5]
    result=[]
    for i in top5_index:
        result.append(corpus[i])
    #return result to html page
    return render_template("simiresult.html",result=result)



#SEARCH_ENGINE
@app.route('/search')
def search():
    return render_template('search.html')

@app.route("/searching",methods=['POST'])
def keywordsearch():
        
    if request.method =='POST':
        sm = request.form['keyword']
        data=pd.read_excel('data.xlsx')
        idea=data.iloc[:,0:1]
        #idea=idea.set_index('Idea')
        corpus=[]
        for index,row in idea.iterrows():
            corpus.append(row['Idea'])
            #length of corpus
        len_corpus=len(corpus)
            #tfidf vectoriser
        test=[sm]
            #test=['LiveChat comes with a built-in online ticketing system. It allows you to handle all your support activities from one place. If a chat can’t be resolved in one touch, agents can escalate it to a ticket to deal with it later.']
            #test=['GIS Based Vehicle Tracking System is one good project. Using GPS receivers, you can develop an efficient system that gives walking directions, bus travel routes, sightseeing, navigation for the blind etc.']
            #test=['online ticketing system']
            #test=['Landmark Solutions/ Location Identification']
            #test=["I want an automatic permission system, that connects with colleges's database and sends mail to coreesponding staff to get permission."]
            #corpus.append(test)
        vectorizer = TfidfVectorizer()
        X=vectorizer.fit_transform(test)
        Xt=vectorizer.transform(np.array(corpus).astype(str))
       #Cosine Similarity
        score=cosine_similarity(Xt,X)
        #Linking scores with the ideas
        idea_index_with_score={}
        for i in range(len_corpus):
            idea_index_with_score.update({i:score[i]})
           #Sorting ideas based on score
            sorted_index = sorted(idea_index_with_score, key=lambda x : idea_index_with_score[x], reverse=True)
           #finding top 5 similar ideas
           #top5_index=sorted_index[:5]
            result=[]
        for i in sorted_index[:20]:
             result.append(corpus[i])
               #return result to html page
    return render_template("searchresult.html",result=result)


#Networking

import sqlite3 as sql

conn = sql.connect('ideanetworking.db')
print ("Opened database successfully");

with conn:
    cur=conn.cursor()
    cur.execute('CREATE TABLE IF NOT EXISTS idea_user(name TEXT, age INT, email TEXT, mobile INT,designation TEXT,interest TEXT,password TEXT,username TEXT)')
    #print ("Table created successfully");
    cur.execute("INSERT INTO idea_user (name,age,email,mobile,designation,interest,password,username) VALUES ('nidisha', 22, 'nidi@gmail.com',9776354875, 'student', 'Artificial intelligence','kiran', 'kiran' )");
    conn.commit()
    #print "Records created successfully";
#cursor = conn.execute("SELECT name, age, email, mobile from idea_user")
#for row in cursor:
 #  print "name = ", row[0]
  # print "age = ", row[1]
   #print "email = ", row[2]
   #print "mobile = ", row[3], "\n"

#print "Operation done successfully";
#conn.close()



@app.route('/enternew')
def new_student():
   return render_template('student.html')

@app.route('/addrec',methods=['POST', 'GET'])
def addrec():
    #print "inside addrec method"
    if request.method=='POST':
        try:
            nam=request.form['nm']
            ag=request.form['age']
            email=request.form['mail']
            mobile=request.form['mob']
            desig=request.form['designation']
            interest = request.form.getlist('check')
            passw=request.form['password']
            user=request.form['username']
            #print nam
            #print interest
            #print email
            con=sql.connect("ideanetworking.db")
            cur = con.cursor()
            cur.execute("INSERT INTO idea_user (name,age,email,mobile,designation,interest,password,username) VALUES (?,?,?,?,?,?,?,?)",(nam,ag,email,mobile,desig,interest,passw,user) );
            con.commit()
            msg= "Record successfully added"
        except:
               #print "ERROR"
               con.rollback()
               msg= "error in insert operation"
        finally:
              return render_template("result.html",msg=msg)
              con.close()
              
@app.route('/list')
def list():
    con=sql.connect("ideanetworking.db")
    con.row_factory = sql.Row
    cur = con.cursor()
    cur.execute("select * from idea_user")
    rows=cur.fetchall();
    return render_template("list.html",rows=rows)

#@app.route('/delete')
#def delete():
  # con=sql.connect("ideanetworking.db")
  # con.row_factory = sql.Row
  # cur = con.cursor()
   #cur.execute("DELETE from idea_user;")
   #rows=cur.fetchall();
   #return render_template("list.html",rows=rows)
        
    

if __name__ == "__main__":
    app.run(debug=True)
